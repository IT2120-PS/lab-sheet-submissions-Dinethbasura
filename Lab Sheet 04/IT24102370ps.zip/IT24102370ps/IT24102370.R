setwd("C:\\Users\\HI\\Documents\\IT24102370ps")


# Part 1
branch_data <- read.table("Exercise.txt", header = TRUE, sep = ",")  
print(branch_data)

# Part 2
str(branch_data)

# part 3
fix(branch_data)
attach(branch_data)
boxplot(branch_data$Sales_X1,
        main = "Boxplot of Sales",
        ylab = "Sales")
# part 4
fivenum(branch_data$Advertising_X2)
IQR(branch_data$Advertising_X2)

# part 5
find_outliers <- function(x) {
  q1 <- quantile(x, 0.25)
  q3 <- quantile(x, 0.75)
  iqr <- q3 - q1
  lower_bound <- q1 - 1.5 * iqr
  upper_bound <- q3 + 1.5 * iqr
  outliers <- x[x < lower_bound | x > upper_bound]
  return(outliers)
}

# Check for outliers in Years_X3
find_outliers(branch_data$Years_X3)








