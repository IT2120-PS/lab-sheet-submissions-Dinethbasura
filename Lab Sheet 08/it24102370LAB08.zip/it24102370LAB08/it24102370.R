getwd()
setwd("C:\\Users\\IT24102370\\Downloads\\Lab 08-IT24102370")


data<-read.table("Exercise - LaptopsWeights.txt",header = TRUE)
fix(data)
attach(data)

#1.
pop_mean <- mean(Weight.kg.)
pop_sd <- sd(Weight.kg.)

#2.
samples <- c()
n <- c()
for(i in 1:25) {
  s <- sample(Weight.kg., 6, replace=TRUE)
  samples <- cbind(samples, s)
  n <- c(n, paste('s', i))
}
colnames(samples) <- n
samples

s.means <- apply(samples, 2, mean)
s.sds <- apply(samples, 2, sd)

#3.
mean_sample_means <- mean(s.means)
sd_sample_means <- sd(s.means)

mean(s.means)
sd(s.means)
