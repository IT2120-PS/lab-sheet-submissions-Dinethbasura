setwd("C://Users//HI//Documents//IT24102370ps")
# Import as a single-column table
DeliveryTimes <- read.table("Exercise - Lab 05.txt", header = TRUE)
# Check structure
str(DeliveryTimes)
# Rename the column for convenience
names(DeliveryTimes)[1] <- "Delivery_Time"
head(DeliveryTimes)
hist(DeliveryTimes$Delivery_Time,
     breaks = seq(20, 70, length.out = 10),  # 9 classes
     right = FALSE,
     col = "skyblue",
     main = "Histogram of Delivery Times",
     xlab = "Delivery Time (minutes)",
     ylab = "Frequency")

# Define class boundaries
breaks <- seq(20, 70, length.out = 10)

# Get frequencies for each interval
freq <- hist(DeliveryTimes$Delivery_Time, breaks = breaks, plot = FALSE)$counts

# Cumulative frequency
cum_freq <- cumsum(freq)

# Display cumulative frequency table
data.frame(
  "Upper Class Boundary" = breaks[-1],
  "Cumulative Frequency" = cum_freq
)

plot(breaks[-1], cum_freq, type = "o", col = "blue",
     main = "Cumulative Frequency Polygon (Ogive)",
     xlab = "Upper Class Boundary (minutes)",
     ylab = "Cumulative Frequency")

