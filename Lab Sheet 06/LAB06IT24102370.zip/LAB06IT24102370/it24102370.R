getwd()
setwd("C:\\Users\\IT24102370\\Downloads\\Lab 06-20250902")
getwd()

#1
#i. What is the distribution of X?
#Binomial distribution
dbinom(46,50,0.85)
pbinom(46, size = 50, prob = 0.85, lower.tail = FALSE)

#2
#i. What is the random variable (X) for the problem?
#number of cutomer calls are received in an hour
#What is the random variable (X) for the problem?
#Poisson distribution


dpois(15, lambda = 12)

