getwd()
setwd("C:\\Users\\IT24102370\\Downloads\\Lab 07-IT24102370")

#Exercise

#1
p(10<x<25)=P(x<=25)-p(x<=10)
punif(25, min = 0, max = 40) - punif(10, min = 0, max = 40)

#2
p(x<=2)
pexp(2, rate = 0.3, lower.tail = T)

#3
1 - pnorm(130, mean = 100, sd = 15, lower.tail = T)

qnorm(0.95, mean = 100, sd = 15, lower.tail = T)
