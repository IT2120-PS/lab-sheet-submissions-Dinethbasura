getwd()
setwd("C:\\Users\\IT24102370\\Downloads\\Lab 09-IT24102370")


# Q1: Generate a random sample of size 25
bake_time <- rnorm(25, mean = 45, sd = 2)
bake_time   # This will print the generated sample

# Q2: Perform hypothesis test
# H0: mu = 46
# H1: mu < 46
t.test(bake_time, mu = 46, alternative = "less")
#p_value is less than 0.05,we reject the null hypothesis.
#the average baking time is less than 46 minutes